# BITACORA.md — Registro del proyecto (v2, desde cero)

Regla: si no está aquí, no pasó. El formato exacto está en
`.agents/skills/bitacora/SKILL.md`. Las entradas se agregan al final; nunca
se editan entradas anteriores (si algo cambió, nueva entrada que lo diga).

---

## 2026-10-20 — Reinicio

- Se congela la corrida anterior como piloto: tag `v0-pilot-2026-10-20` en el
  repo `alebar000/moonstorm-smoothfaces-epic`. No se vuelve a escribir en esa rama.
- Causas del reinicio (resumen de Alex): sin style bible congelado; el agente
  regeneraba assets aprobados; críticos sintéticos sin relación con el juicio
  humano; alcance cambiando a mitad de loop; objetos recortados de fondos
  compuestos; anatomía rota (un brazo, ojos desalineados); alturas de
  personajes inconsistentes.
- Nuevo kit instalado: `AGENTS.md`, `STYLE_BIBLE.md`, `SLICE.md`, skills en
  `.agents/skills/`, hoja de revisión en `review/`, gates en `pipeline/`.

